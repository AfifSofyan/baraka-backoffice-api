export default [
    { month: 1, numeral: 'I'},
    { month: 2, numeral: 'II'},
    { month: 3, numeral: 'III'},
    { month: 4, numeral: 'IV'},
    { month: 5, numeral: 'V'},
    { month: 6, numeral: 'VI'},
    { month: 7, numeral: 'VII'},
    { month: 8, numeral: 'VIII'},
    { month: 9, numeral: 'IX'},
    { month: 10, numeral: 'X'},
    { month: 11, numeral: 'XI'},
    { month: 12, numeral: 'XII'},    
]