export default {
    SUPERADMIN:1,
    ADMIN:2,
    TUTOR:3,
    STUDENT:4,
}