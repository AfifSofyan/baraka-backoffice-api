export default {
    AKTIF:1,
    LIBUR:2,
    OFF:3,
    PENDAFTAR_BARU: 4,
}