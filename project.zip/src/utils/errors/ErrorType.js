export default{
    customErrType : "CUSTOM_ERR_OBJ"
}